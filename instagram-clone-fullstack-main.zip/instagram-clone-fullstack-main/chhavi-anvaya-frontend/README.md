# Chhavi-Anvaya-frontend

## To Run Frontend

- Refer `.env.sample` file and create `.env` file in root folder.
- Now Copy the content from `.env.sample` to `.env`
- Make sure you are using correct port number.
- Now run `npm install` to install all the required packages.
- Now run `npm start` the frontend service will start running on the port specified, you will be able to see the port details on the console.
